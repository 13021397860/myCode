#ifndef STUDENT_H_INCLUDED
#define STUDENT_H_INCLUDED
#include"course.h"
#include "ObligatoryCourse.h"
#include "ElectiveCourse.h"
#include"Date.h"
#define Max_size 20
class Student
{
    friend ostream &operator<<(ostream &,const Student&);
    public:

        Student();
        Student(int =1,int =1,int =1,const char* =NULL);
        Student(const Student &);
        virtual ~Student();
        void setName(const char *);
        char *getName()const;
        Date getBirthDate()const;
        void printStu()const;
        static void printCnt();
        Student& addCourse1(const string &courseNa,int creditHour,int m);
        Student& addCourse2(const string& courseNa,int creditH,char g);
        Student& addCourse3(course *course_);


    private:
        char *name ;
        const Date birthDate;
        static int cnt;
        course *courseList[Max_size];//Ҫnew
        int courseNumber;
};

#endif // DATE_H_INCLUDED
