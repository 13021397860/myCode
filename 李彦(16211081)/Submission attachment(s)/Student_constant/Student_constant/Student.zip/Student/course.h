#ifndef COURSE_H
#define COURSE_H
#include<iostream>
using std::string;
using std::ostream;
class course
{
    public:
        string name;
        int creditHour;
        course();
        course(const string ,int);
        virtual ~course();
        string  getName() const ;
        int getCredit() const ;
        void  set_(string, int );
        virtual void print(){};//�麯����
    protected:

//friend ostream &operator<<(ostream &os,const course &course_);
    private:


};

#endif // COURSE_H
