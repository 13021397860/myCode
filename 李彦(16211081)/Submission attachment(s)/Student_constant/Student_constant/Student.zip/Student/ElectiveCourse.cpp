#include "ElectiveCourse.h"
#include<iostream>
using std::cout;
using std::string;
using std::endl;
using std::cin;
ElectiveCourse::ElectiveCourse()
{
    //ctor
}

ElectiveCourse::ElectiveCourse(string n,int c,char g)
{
    name=n;
    creditHour=c;
    grade=g;//ctor
}

ElectiveCourse::~ElectiveCourse()
{
    //dtor
}

void ElectiveCourse::set_(string n,int c,char g)
{
    course::set_(n,c);
    grade=g;
}

char ElectiveCourse::getEGrade()
{
    return grade;
}

void ElectiveCourse::print()
{
    cout<<"coursename:"<<name<<" creditHour:"<<creditHour<<" grade:"<<grade<<endl;
}
