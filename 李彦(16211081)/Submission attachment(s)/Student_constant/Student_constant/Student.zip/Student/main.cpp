#include<iostream>
#include"Date.h"
#include"course.h"
#include "ObligatoryCourse.h"
#include "ElectiveCourse.h"
#include"Student.h"
#include<cstring>
using std::cout;
using std::string;
using std::endl;
using std::cin;

int main()
{
    int y,m,d;
    string str4;
        Student a(1998,8,20,"jack");
        a.addCourse3(new ObligatoryCourse("english",4,100));//��һ��oblicourse��ָ�봫��student��courselist��Ϊָ������Ԫ�أ�
        a.addCourse2("cplusplus",4,'A');//�������γ�ָ�룻
        a.printStu();
        /*a.addCourse2("linear algebra",4,'A');
        cout<<"add 2"<<endl;
        a.printStu();
        cout<<"main end"<<endl;*/
}

