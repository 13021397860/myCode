#ifndef STUDENT_H
#define STUDENT_H


class Student
{
    public:
        Student();
        virtual ~Student();

    protected:

    private:
};

#endif // STUDENT_H
