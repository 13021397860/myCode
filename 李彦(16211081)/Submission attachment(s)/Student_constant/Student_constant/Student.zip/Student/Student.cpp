#include<iostream>
#include<string.h>
#include"Student.h"
#include"Date.h"
#include"course.h"
#include "ObligatoryCourse.h"
#include "ElectiveCourse.h"
using namespace std;
int Student::cnt=0;
/*void Student::setBirthDate(const Date &date1)
{
    birthDate(date1);
}*/

Student::Student()
:birthDate(1,1,1)
{
    courseNumber=0;
    cnt++;
    name="Mary";
}

Student::Student(int y,int m,int d,const char *str1)
:birthDate(y,m,d)//**
{
    courseNumber=0;
    cnt++;
    name=new char[strlen(str1)+1];
    setName(str1);
}

Student::Student(const Student &s1)
:birthDate(s1.birthDate)//���ں����еĳ�ʼ����������
{
    cnt++;
    name =new char[strlen(s1.name)+1];
    strcpy(name,s1.name);
}

Student::~Student()
{
    delete[]name;
    for(int i=0;i<=courseNumber-1;i++)
    {
        delete courseList[i];//ָ���������һ����delete������ǵ������飬����name��
    }
    cout<<"Student is destroyed"<<endl;
}

void Student::setName(const char *str1)
{
    strcpy(name,str1);
}

/*void Student::setBirthDate(int y,int m,int d)
{
    birthDate.setDate(y,m,d);
}*/

char *Student::getName() const
{
    return name;
}

Date Student::getBirthDate() const
{
    return birthDate;
}

void Student::printStu() const
{
    cout<<name<<" ";
    cout<<birthDate.getYear()<<" ";
    cout<<birthDate.getMonth()<<" ";
    cout<<birthDate.getDay()<<" ";
    cout<<"coursenumber:"<<courseNumber<<endl;
    for(int i=0;i<=courseNumber-1;i++)  courseList[i]->print();//����������������ѡ��print���ͣ�
}
void  Student::printCnt()
{
    cout<<cnt<<endl;
}

Student& Student::addCourse1(const string& courseNa,int creditH,int m)
{
    if(courseNumber<Max_size)
    {
        courseList[courseNumber++]=new ObligatoryCourse(courseNa,creditH,m);//�½�һ��course���󣬲��������ĵ�ַ��
    }
    return *this;
}

Student& Student::addCourse2(const string& courseNa,int creditH,char g)
{
    if(courseNumber<Max_size)
    {
        courseList[courseNumber++]=new ElectiveCourse(courseNa,creditH,g);//�½�һ��course���󣬲��������ĵ�ַ��
    }
    return *this;
}

Student& Student::addCourse3(course *course_)
{
    if(courseNumber<Max_size)   courseList[courseNumber++]=course_;//
    return *this;
}

/*ostream &operator<<(ostream &output,const Student&stu)
{
    output<<stu.name<<" "<<stu.birthDate;
    int i;
    for(i=0;i<=stu.courseNumber-1;i++)
    {
        output<<*(stu.courseList[i]);
    }
    return output;
}*/
