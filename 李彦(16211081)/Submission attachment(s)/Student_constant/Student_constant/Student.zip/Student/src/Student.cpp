#include "Student.h"

Student::Student()
{
    //ctor
}

Student::~Student()
{
    //dtor
}
