#include <iostream>
#include "date.h"
#include "Student.h"

#include "Obligatorycourse .h"
#include "electivecourse.h"
#include "course.h"
#include <vector>
#include <string>
using namespace std;
#include "Console.h"
int main()
{
	
	Console c;
	c.run();

	system("pause");
}
