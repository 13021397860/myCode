﻿#ifndef DATE_H
#define DATE_H

#define  _CRT_SECURE_NO_WARNINGS
/************************************************************************/
/* •	Data类功能需求
（1）数据成员：年year、月month、日day
（2）定义构造函数和拷贝构造函数（下周完成）
（3）定义get和set函数，存取私有数据成员
（1）定义成员函数isLeapYear()，测试当前的年份是否是闰年，函数返回类型为bool类型
（5）定义成员函数nextDay() ，将当前日期递增1天
（6）定义成员函数print()，输出当前日期
（7）在单独的cpp文件中编写main函数，测试各项功能
                                                                     */
/************************************************************************/
#include <iostream>
using namespace std;
class Date
{

public:

	friend istream& operator>> (istream& os,Date& date);
	friend ostream& operator<<(ostream&os,const Date&date);



	virtual ~Date();
	Date(int = 1900, int = 1, int = 1);//构造函数
	Date(const Date &);//拷贝构造函数
	inline int getMonth()const  { return month; }
	inline int getDay() const { return day; }
	inline int getYear() const { return year; }
	bool setDate(int y, int m, int d);
	bool isLeapyear()const;//判断闰年
	void nextDate();//递增一天，注意点为需要日满进月，月满进年

	 Date& operator++();  //重载前++；
	 Date operator++(int);//重载后++

protected:

private:
	int year;
	int month;
	int day;
    bool check();
};

#endif // DATE_H
