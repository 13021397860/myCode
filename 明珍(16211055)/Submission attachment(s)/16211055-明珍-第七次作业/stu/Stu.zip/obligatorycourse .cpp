#include "obligatorycourse .h"//����


#if 1

ObligatoryCourse ::ObligatoryCourse (string n,int h):Course(n,h)
{
    //ctor
	type = 1;
}


ObligatoryCourse ::~ObligatoryCourse ()
{
    //dtor
}

#endif