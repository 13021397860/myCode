#ifndef ELECTIVECOURSE _H
#define ELECTIVECOURSE _H//ѡ��

#include "Course.h"

#define  _CRT_SECURE_NO_WARNINGS
class ElectiveCourse : public Course
{
public:
	
	ElectiveCourse(string, int);
	virtual ~ElectiveCourse();
	inline void setGrade(char grade) {
		this->grade = grade;
	}
	inline char getGrade() const { return grade; }
	virtual int  getScore()const;
protected:

private:
	char grade;

};

#endif // ELECTIVECOURSE _H
