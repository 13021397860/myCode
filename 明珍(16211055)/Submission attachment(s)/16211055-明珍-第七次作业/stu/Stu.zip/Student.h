#ifndef STUDATE_H
#define STUDATE_H
#include "Date.h"
#include "Course.h"

#include <string>


/************************************************************************/
/* Studata类功能需求
	数据成员：姓名name，必须使用char*类型（不能使用char[],或string），在构造和析构函数中实现动态内存分配
	组成数据成员：出生日期birthDate，使用实验1所完成的Date类型
	静态数据成员：学生数量count，用于统计在程序中产生学生对象的个数（第二次完成）
	提供构造函数、拷贝构造函数和析构函数
	提供必要的get和set函数，存取私有数据成员
	在单独的cpp文件中编写main函数，测试各项功能
                                                                     */
/************************************************************************/
/************************************************************************/
/* 完善学生类Student
（3.1）增加数据成员courseList，类型为Course类指针数组(即 为Course *courseList[MAX_SIZE]，MAX_SIZE为常量宏，表示可选的最大课程数)，表示学生所选的所有课程
（3.2）增加数据成员courseNumber，int类型，表示实际的课程总数
（3.3）不修改构造函数（构造学生的时候还没有课程），添加addCourse接口，即实现学生选课，接口如下：
Student& addCourse(Course *course);
Student& addCourse(const string &courseName, int creditHour);
（3.4）重载流输出运算符<<，输出学生姓名、生日以及所选课程信息，输出格式如下示例：
姓名：李四 出生日期：1987-3-1，选课信息如下：
	   课程名：面向对象的程序设计    学分：3
	   课程名：数学分析   学分：5
	   课程名：体育    学分：2
（4）编写main函数，测试所要求的功能
                                                                     */
/************************************************************************/
#define MAX_SIZE 50
using namespace std;
#define  _CRT_SECURE_NO_WARNINGS
class Student
{
public:
	friend ostream& operator<<(ostream& o, const Student& c);

	virtual ~Student();
	Student(const string &name, const Date& birthDate);
	Student(const char* const, int, int, int);//构造函数
	Student(const Student&);//拷贝构造
	inline char *getName()const { return name; }//可以不用get  直接输出name
	inline Date getBirthDate() const{
		return birthDate;
	}
	void setBirthdate(const Date& date);
	void setName(char *);
	//Course *courseList[MAX_SIZE];
	void printf();
	Student& addCourse(Course *course);
	Student& addCourse(const string &courseName, int creditHour);
	inline  int setCourseNumber(int n) {
		courseNumber = n;
	}
	inline int getCourseNumber() const { return courseNumber; }
	Course *courseList[MAX_SIZE];
	bool removeCourse(int i);

	/************************************************************************/
	/* 
	
	n	成员函数calcCredit，计算学生积点成绩，算法如下：
u	必修课权重*SUM(必修课成绩*必修课学分/所选必修课总学分)+选修课权重*SUM(选修课成绩/所选选修课总门数)
u	其中：必修课权重+选修课权重=1，目前取必修课权重0.6，选修课权重0.4；SUM表示所有课程项求和

	*/
	/************************************************************************/

	float calcCredit()const;

protected:

 private:
    char* name;
    Date birthDate;
    static int  count;
    int courseNumber;

};
#endif // STUDATE_H
;
