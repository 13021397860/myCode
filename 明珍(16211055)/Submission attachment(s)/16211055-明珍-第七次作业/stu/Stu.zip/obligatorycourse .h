#ifndef OBLIGATORYCOURSE _H
#define OBLIGATORYCOURSE _H//����

#include "course.h"
#define  _CRT_SECURE_NO_WARNINGS

class ObligatoryCourse : public Course
{
public:
	ObligatoryCourse(string, int);
	virtual ~ObligatoryCourse();
	inline void setMark(int mark) {
		this->mark = mark;
	}
	inline virtual int getScore()const {
		return mark;
	}

	

private:
	int mark;
};



#endif // OBLIGATORYCOURSE _H
