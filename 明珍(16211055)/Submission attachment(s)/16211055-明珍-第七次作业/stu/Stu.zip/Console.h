#pragma once
class Console
{
public:
	Console();
	~Console();

	void run();

};

